// أسعار الصرف المحدثة (شاملة الريال اليمني)
const exchangeRates = {
    USD: 1,
    EUR: 0.92,
    GBP: 0.79,
    JPY: 150.50,
    CHF: 0.88,
    CAD: 1.35,
    AUD: 1.52,
    CNY: 7.19,
    RUB: 91.50,
    TRY: 32.20,
    SAR: 3.75,
    AED: 3.67,
    QAR: 3.64,
    KWD: 0.31,
    BHD: 0.38,
    OMR: 0.38,
    YER: 250.50, // الريال اليمني
    EGP: 30.90,
    JOD: 0.71,
    LBP: 89500,
    IQD: 1310,
    LYD: 4.85,
    MAD: 10.06,
    TND: 3.12,
    DZD: 134.50,
    SDG: 601.50,
    SYP: 13000
};

// معلومات العملات
const currencyInfo = {
    USD: { name: 'دولار أمريكي', symbol: '$', flag: '🇺🇸' },
    EUR: { name: 'يورو', symbol: '€', flag: '🇪🇺' },
    GBP: { name: 'جنيه إسترليني', symbol: '£', flag: '🇬🇧' },
    JPY: { name: 'ين ياباني', symbol: '¥', flag: '🇯🇵' },
    CHF: { name: 'فرنك سويسري', symbol: 'Fr', flag: '🇨🇭' },
    CAD: { name: 'دولار كندي', symbol: 'C$', flag: '🇨🇦' },
    AUD: { name: 'دولار أسترالي', symbol: 'A$', flag: '🇦🇺' },
    CNY: { name: 'يوان صيني', symbol: '¥', flag: '🇨🇳' },
    RUB: { name: 'روبل روسي', symbol: '₽', flag: '🇷🇺' },
    TRY: { name: 'ليرة تركية', symbol: '₺', flag: '🇹🇷' },
    SAR: { name: 'ريال سعودي', symbol: '﷼', flag: '🇸🇦' },
    AED: { name: 'درهم إماراتي', symbol: 'د.إ', flag: '🇦🇪' },
    QAR: { name: 'ريال قطري', symbol: 'ر.ق', flag: '🇶🇦' },
    KWD: { name: 'دينار كويتي', symbol: 'د.ك', flag: '🇰🇼' },
    BHD: { name: 'دينار بحريني', symbol: 'د.ب', flag: '🇧🇭' },
    OMR: { name: 'ريال عماني', symbol: 'ر.ع', flag: '🇴🇲' },
    YER: { name: 'ريال يمني', symbol: '﷼', flag: '🇾🇪' },
    EGP: { name: 'جنيه مصري', symbol: 'ج.م', flag: '🇪🇬' },
    JOD: { name: 'دينار أردني', symbol: 'د.ا', flag: '🇯🇴' },
    LBP: { name: 'ليرة لبنانية', symbol: 'ل.ل', flag: '🇱🇧' },
    IQD: { name: 'دينار عراقي', symbol: 'د.ع', flag: '🇮🇶' },
    LYD: { name: 'دينار ليبي', symbol: 'د.ل', flag: '🇱🇾' },
    MAD: { name: 'درهم مغربي', symbol: 'د.م', flag: '🇲🇦' },
    TND: { name: 'دينار تونسي', symbol: 'د.ت', flag: '🇹🇳' },
    DZD: { name: 'دينار جزائري', symbol: 'د.ج', flag: '🇩🇿' },
    SDG: { name: 'جنيه سوداني', symbol: 'ج.س', flag: '🇸🇩' },
    SYP: { name: 'ليرة سورية', symbol: 'ل.س', flag: '🇸🇾' }
};

// متغيرات التطبيق
let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
let lastConversion = null;

// دالة تحويل الأرقام إلى كتابة عربية
function numberToArabicWords(number, currency) {
    if (isNaN(number) || number === 0) return 'صفر';
    
    const units = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
    const tens = ['', 'عشرة', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    const hundreds = ['', 'مئة', 'مئتان', 'ثلاثمئة', 'أربعمئة', 'خمسمئة', 'ستمئة', 'سبعمئة', 'ثمانمئة', 'تسعمئة'];
    const thousands = ['', 'ألف', 'ألفان', 'آلاف'];
    
    let words = '';
    let num = Math.floor(number);
    
    if (num >= 1000) {
        const thousandCount = Math.floor(num / 1000);
        if (thousandCount === 1) words += 'ألف ';
        else if (thousandCount === 2) words += 'ألفان ';
        else if (thousandCount >= 3 && thousandCount <= 10) words += units[thousandCount] + ' آلاف ';
        else words += units[thousandCount] + ' ألف ';
        num %= 1000;
    }
    
    if (num >= 100) {
        const hundredCount = Math.floor(num / 100);
        words += hundreds[hundredCount] + ' ';
        num %= 100;
    }
    
    if (num >= 20) {
        const tenCount = Math.floor(num / 10);
        words += tens[tenCount] + ' ';
        num %= 10;
    } else if (num >= 10) {
        if (num === 10) words += 'عشرة ';
        else if (num === 11) words += 'أحد عشر ';
        else if (num === 12) words += 'اثنا عشر ';
        else words += units[num % 10] + ' عشر ';
        num = 0;
    }
    
    if (num > 0) {
        words += units[num] + ' ';
    }
    
    // إضافة اسم العملة
    const currencyName = currencyInfo[currency]?.name || '';
    
    return words.trim() + ' ' + currencyName;
}

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    console.log('تم تهيئة التطبيق بنجاح');
    
    // إضافة مستمعي الأحداث
    document.getElementById('amount').addEventListener('input', convertCurrency);
    document.getElementById('fromCurrency').addEventListener('change', function() {
        updateInputCurrencySymbol();
        convertCurrency();
    });
    document.getElementById('toCurrency').addEventListener('change', function() {
        updateResultCurrencySymbol();
        convertCurrency();
    });
    
    // تهيئة الرموز
    updateInputCurrencySymbol();
    updateResultCurrencySymbol();
    
    // تنفيذ التحويل الأولي
    setTimeout(() => {
        convertCurrency();
    }, 100);
    
    updateLastUpdated();
    displayTodayRates();
    createQuickButtons();
    loadFavorites();
    
    // تحديث الوقت كل ثانية
    setInterval(updateLastUpdated, 1000);
}

// دالة تحديث رمز عملة الإدخال
function updateInputCurrencySymbol() {
    const fromCurrency = document.getElementById('fromCurrency').value;
    const symbol = currencyInfo[fromCurrency]?.symbol || '$';
    document.getElementById('inputCurrencySymbol').textContent = symbol;
}

// دالة تحديث رمز عملة النتيجة
function updateResultCurrencySymbol() {
    // هذه الدالة اختيارية حسب احتياجك
}

// دالة التحويل الرئيسية
function convertCurrency() {
    console.log('جاري التحويل...');
    
    try {
        // الحصول على القيم
        const amountInput = document.getElementById('amount');
        const fromSelect = document.getElementById('fromCurrency');
        const toSelect = document.getElementById('toCurrency');
        const resultDiv = document.getElementById('result');
        const rateInfoDiv = document.getElementById('rateInfo');
        const additionalInfoDiv = document.getElementById('additionalInfo');
        const arabicTextDiv = document.getElementById('arabicTextResult');
        
        const amount = parseFloat(amountInput.value);
        const fromCurrency = fromSelect.value;
        const toCurrency = toSelect.value;
        
        console.log('المبلغ:', amount);
        console.log('من:', fromCurrency);
        console.log('إلى:', toCurrency);
        
        // التحقق من صحة المبلغ
        if (isNaN(amount) || amount < 0) {
            resultDiv.textContent = '❌ خطأ في المبلغ';
            showError('الرجاء إدخال مبلغ صحيح');
            return;
        }
        
        if (amount === 0) {
            resultDiv.textContent = '0.00';
            rateInfoDiv.textContent = `1 ${fromCurrency} = 0 ${toCurrency}`;
            if (additionalInfoDiv) {
                additionalInfoDiv.textContent = '';
            }
            if (arabicTextDiv) {
                arabicTextDiv.innerHTML = '<p>المبلغ: صفر</p>';
            }
            return;
        }
        
        // التحقق من وجود العملات في قائمة الأسعار
        if (!exchangeRates[fromCurrency] || !exchangeRates[toCurrency]) {
            throw new Error('بيانات العملة غير متوفرة');
        }
        
        // حساب السعر
        const rate = exchangeRates[toCurrency] / exchangeRates[fromCurrency];
        const convertedAmount = amount * rate;
        
        console.log('سعر الصرف:', rate);
        console.log('النتيجة:', convertedAmount);
        
        // حفظ آخر تحويل
        lastConversion = {
            amount,
            from: fromCurrency,
            to: toCurrency,
            result: convertedAmount,
            rate
        };
        
        // عرض النتيجة مع التنسيق
        const toSymbol = currencyInfo[toCurrency]?.symbol || '';
        const fromSymbol = currencyInfo[fromCurrency]?.symbol || '';
        const fromName = currencyInfo[fromCurrency]?.name || fromCurrency;
        const toName = currencyInfo[toCurrency]?.name || toCurrency;
        
        // تنسيق الأرقام حسب العملة
        let formattedResult;
        if (toCurrency === 'JPY' || toCurrency === 'LBP' || toCurrency === 'IQD' || toCurrency === 'YER') {
            formattedResult = convertedAmount % 1 === 0 ? 
                convertedAmount.toFixed(0) : 
                convertedAmount.toFixed(2);
        } else {
            formattedResult = convertedAmount.toFixed(2);
        }
        
        resultDiv.textContent = `${formattedResult} ${toSymbol}`;
        
        // عرض معلومات سعر الصرف
        rateInfoDiv.textContent = `1 ${fromSymbol}${fromCurrency} = ${rate.toFixed(4)} ${toSymbol}${toCurrency}`;
        
        // عرض معلومات إضافية
        if (additionalInfoDiv) {
            const inverseRate = 1 / rate;
            additionalInfoDiv.textContent = `1 ${toSymbol}${toCurrency} = ${inverseRate.toFixed(4)} ${fromSymbol}${fromCurrency}`;
        }
        
        // عرض المبلغ كتابة بالعربية
        if (arabicTextDiv) {
            const amountWords = numberToArabicWords(amount, fromCurrency);
            const resultWords = numberToArabicWords(convertedAmount, toCurrency);
            
            arabicTextDiv.innerHTML = `
                <p>
                    <i class="fas fa-pen"></i>
                    المبلغ المحول كتابة:
                </p>
                <span class="arabic-text-amount">
                    ${amountWords} يساوي ${resultWords}
                </span>
            `;
        }
        
        // تحديث أسعار اليوم
        displayTodayRates();
        
        // تحديث المفضلة إذا كانت مفتوحة
        if (document.getElementById('favoritesSection').style.display !== 'none') {
            updateFavoritesDisplay();
        }
        
        // إخفاء رسالة الخطأ إذا كانت ظاهرة
        hideError();
        
        // حفظ آخر تحويل في localStorage
        saveLastConversion(amount, fromCurrency, toCurrency, convertedAmount);
        
        console.log('تم التحويل بنجاح');
        
    } catch (error) {
        console.error('خطأ في التحويل:', error);
        showError('حدث خطأ في عملية التحويل: ' + error.message);
    }
}

// دالة تبديل العملات
function swapCurrencies() {
    const fromSelect = document.getElementById('fromCurrency');
    const toSelect = document.getElementById('toCurrency');
    
    const tempValue = fromSelect.value;
    const tempText = fromSelect.options[fromSelect.selectedIndex].text;
    
    fromSelect.value = toSelect.value;
    toSelect.value = tempValue;
    
    updateInputCurrencySymbol();
    convertCurrency();
    
    showSuccess('تم تبديل العملات بنجاح');
}

// دالة عرض أسعار اليوم
function displayTodayRates() {
    const ratesGrid = document.getElementById('todayRates');
    if (!ratesGrid) return;
    
    let html = '';
    const baseCurrency = 'USD';
    const baseRate = exchangeRates[baseCurrency];
    
    // اختيار أهم العملات للعرض
    const mainCurrencies = ['EUR', 'GBP', 'JPY', 'CNY', 'SAR', 'AED', 'YER', 'EGP', 'TRY', 'KWD'];
    
    mainCurrencies.forEach(currency => {
        if (exchangeRates[currency]) {
            const rate = exchangeRates[currency] / baseRate;
            const info = currencyInfo[currency];
            const change = (Math.random() * 2 - 1).toFixed(2); // تغيير عشوائي للعرض
            
            html += `
                <div class="rate-item">
                    <div class="rate-flag">${info?.flag || '🏳️'}</div>
                    <div class="rate-code">${currency}</div>
                    <div class="rate-value">${rate.toFixed(4)}</div>
                    <div class="rate-change ${change >= 0 ? 'up' : 'down'}">
                        <i class="fas fa-${change >= 0 ? 'arrow-up' : 'arrow-down'}"></i>
                        ${Math.abs(change)}%
                    </div>
                </div>
            `;
        }
    });
    
    ratesGrid.innerHTML = html;
}

// دالة إنشاء أزرار التحويل السريع
function createQuickButtons() {
    const quickButtons = document.getElementById('quickButtons');
    if (!quickButtons) return;
    
    const quickPairs = [
        { from: 'USD', to: 'EUR' },
        { from: 'USD', to: 'GBP' },
        { from: 'USD', to: 'JPY' },
        { from: 'USD', to: 'YER' },
        { from: 'USD', to: 'SAR' },
        { from: 'EUR', to: 'USD' },
        { from: 'GBP', to: 'USD' },
        { from: 'YER', to: 'USD' },
        { from: 'SAR', to: 'YER' },
        { from: 'AED', to: 'YER' }
    ];
    
    let html = '';
    quickPairs.forEach(pair => {
        const fromInfo = currencyInfo[pair.from];
        const toInfo = currencyInfo[pair.to];
        html += `
            <button class="quick-btn" onclick="quickConvert('${pair.from}', '${pair.to}')">
                ${fromInfo?.flag || '🏳️'} ${pair.from} → ${toInfo?.flag || '🏳️'} ${pair.to}
            </button>
        `;
    });
    
    quickButtons.innerHTML = html;
}

// دالة التحويل السريع
function quickConvert(from, to) {
    document.getElementById('fromCurrency').value = from;
    document.getElementById('toCurrency').value = to;
    updateInputCurrencySymbol();
    convertCurrency();
    showSuccess(`تم التبديل إلى ${from} → ${to}`);
}

// دالة عرض رسالة الخطأ
function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    
    if (errorDiv && errorText) {
        errorText.textContent = message;
        errorDiv.style.display = 'flex';
        
        setTimeout(() => {
            errorDiv.style.display = 'none';
        }, 3000);
    }
}

// دالة إخفاء رسالة الخطأ
function hideError() {
    const errorDiv = document.getElementById('errorMessage');
    if (errorDiv) {
        errorDiv.style.display = 'none';
    }
}

// دالة عرض رسالة النجاح
function showSuccess(message) {
    const successDiv = document.getElementById('successMessage');
    const successText = document.getElementById('successText');
    
    if (successDiv && successText) {
        successText.textContent = message;
        successDiv.style.display = 'flex';
        
        setTimeout(() => {
            successDiv.style.display = 'none';
        }, 2000);
    }
}

// دالة تحديث وقت آخر تحديث
function updateLastUpdated() {
    const lastUpdated = document.getElementById('lastUpdated');
    if (!lastUpdated) return;
    
    const now = new Date();
    const options = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    };
    
    lastUpdated.innerHTML = `<i class="fas fa-clock"></i> آخر تحديث: ${now.toLocaleDateString('ar-EG', options)}`;
}

// دالة حفظ آخر تحويل
function saveLastConversion(amount, from, to, result) {
    const conversion = {
        amount: amount,
        from: from,
        to: to,
        result: result,
        timestamp: new Date().toISOString()
    };
    
    try {
        localStorage.setItem('lastConversion', JSON.stringify(conversion));
    } catch (e) {
        console.log('غير قادر على حفظ التحويل');
    }
}

// دالة إعادة التعيين
function resetToDefault() {
    document.getElementById('amount').value = 1;
    document.getElementById('fromCurrency').value = 'USD';
    document.getElementById('toCurrency').value = 'YER';
    updateInputCurrencySymbol();
    convertCurrency();
    showSuccess('تم إعادة التعيين إلى الإعدادات الافتراضية');
}

// دالة جلب أسعار حقيقية
async function fetchRealRates() {
    showSuccess('جاري تحديث الأسعار...');
    
    try {
        // محاكاة جلب البيانات (يمكن استبدالها بـ API حقيقي)
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // تحديث بعض الأسعار بشكل عشوائي
        for (let currency in exchangeRates) {
            if (currency !== 'USD') {
                const change = (Math.random() * 0.02) - 0.01; // تغيير بين -1% و +1%
                exchangeRates[currency] = exchangeRates[currency] * (1 + change);
            }
        }
        
        convertCurrency();
        displayTodayRates();
        showSuccess('تم تحديث الأسعار بنجاح');
        
    } catch (error) {
        showError('فشل تحديث الأسعار');
    }
}

// دوال المفضلة
function toggleFavorite() {
    const fromCurrency = document.getElementById('fromCurrency').value;
    const toCurrency = document.getElementById('toCurrency').value;
    const pair = `${fromCurrency}/${toCurrency}`;
    const favoriteIcon = document.getElementById('favoriteIcon');
    
    const index = favorites.indexOf(pair);
    
    if (index === -1) {
        favorites.push(pair);
        favoriteIcon.className = 'fas fa-star';
        showSuccess('تمت الإضافة إلى المفضلة');
    } else {
        favorites.splice(index, 1);
        favoriteIcon.className = 'far fa-star';
        showSuccess('تمت الإزالة من المفضلة');
    }
    
    localStorage.setItem('favorites', JSON.stringify(favorites));
    loadFavorites();
}

function loadFavorites() {
    const favoritesSection = document.getElementById('favoritesSection');
    const favoritesGrid = document.getElementById('favoritesGrid');
    
    if (!favoritesSection || !favoritesGrid) return;
    
    if (favorites.length === 0) {
        favoritesSection.style.display = 'none';
        return;
    }
    
    favoritesSection.style.display = 'block';
    
    let html = '';
    favorites.forEach(pair => {
        const [from, to] = pair.split('/');
        const rate = exchangeRates[to] / exchangeRates[from];
        const fromInfo = currencyInfo[from];
        const toInfo = currencyInfo[to];
        
        html += `
            <div class="favorite-item" onclick="quickConvert('${from}', '${to}')">
                <div>
                    <span class="currency-pair">${fromInfo?.flag || '🏳️'} ${from} → ${toInfo?.flag || '🏳️'} ${to}</span>
                    <div class="favorite-value">${rate.toFixed(4)}</div>
                </div>
                <span class="remove-favorite" onclick="removeFromFavorite('${pair}'); event.stopPropagation();">
                    <i class="fas fa-times"></i>
                </span>
            </div>
        `;
    });
    
    favoritesGrid.innerHTML = html;
}

function removeFromFavorite(pair) {
    const index = favorites.indexOf(pair);
    if (index > -1) {
        favorites.splice(index, 1);
        localStorage.setItem('favorites', JSON.stringify(favorites));
        loadFavorites();
        
        // تحديث أيقونة المفضلة إذا كانت هذه الزوج الحالي
        const fromCurrency = document.getElementById('fromCurrency').value;
        const toCurrency = document.getElementById('toCurrency').value;
        const currentPair = `${fromCurrency}/${toCurrency}`;
        
        if (currentPair === pair) {
            document.getElementById('favoriteIcon').className = 'far fa-star';
        }
        
        showSuccess('تمت الإزالة من المفضلة');
    }
}

function updateFavoritesDisplay() {
    const favoritesGrid = document.getElementById('favoritesGrid');
    if (!favoritesGrid || favorites.length === 0) return;
    
    let html = '';
    favorites.forEach(pair => {
        const [from, to] = pair.split('/');
        const rate = exchangeRates[to] / exchangeRates[from];
        const fromInfo = currencyInfo[from];
        const toInfo = currencyInfo[to];
        
        html += `
            <div class="favorite-item" onclick="quickConvert('${from}', '${to}')">
                <div>
                    <span class="currency-pair">${fromInfo?.flag || '🏳️'} ${from} → ${toInfo?.flag || '🏳️'} ${to}</span>
                    <div class="favorite-value">${rate.toFixed(4)}</div>
                </div>
                <span class="remove-favorite" onclick="removeFromFavorite('${pair}'); event.stopPropagation();">
                    <i class="fas fa-times"></i>
                </span>
            </div>
        `;
    });
    
    favoritesGrid.innerHTML = html;
}

// التأكد من أن جميع الدوال متاحة في النطاق العام
window.convertCurrency = convertCurrency;
window.swapCurrencies = swapCurrencies;
window.fetchRealRates = fetchRealRates;
window.resetToDefault = resetToDefault;
window.toggleFavorite = toggleFavorite;
window.quickConvert = quickConvert;
window.removeFromFavorite = removeFromFavorite;